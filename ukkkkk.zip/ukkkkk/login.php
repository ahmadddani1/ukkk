<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Web Galeri Foto</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body id="bg-login">
    <div class="box-login">
        <h2>Login</h2>
        <form action="" method="POST">
            <input type="text" name="user" placeholder="Username" class="input-control">
            <input type="password" name="pass" placeholder="Password" class="input-control">
            <input type="submit" name="submit" value="Login" class="btn">
        </form>
        <?php
            session_start(); // Mulai sesi di awal

            if(isset($_POST['submit'])){
                include 'db.php'; // Sertakan file koneksi database

                // Ambil dan sanitasi input username dan password
                $user = mysqli_real_escape_string($conn, $_POST['user']);
                $pass = mysqli_real_escape_string($conn, $_POST['pass']);

                // Query untuk memeriksa keberadaan kombinasi username dan password di database
                $cek = mysqli_query($conn, "SELECT * FROM tb_admin WHERE username = '$user' AND password = '$pass'");
                if(mysqli_num_rows($cek) > 0){
                    // Jika kombinasi username dan password ditemukan, set session dan arahkan ke dashboard
                    $d = mysqli_fetch_object($cek);
                    $_SESSION['status_login'] = true;
                    $_SESSION['a_global'] = $d;
                    $_SESSION['id'] = $d->admin_id;
                    header("Location: dashboard.php");
                    exit(); // Pastikan untuk keluar dari skrip setelah mengarahkan pengguna
                }else{
                    // Jika kombinasi tidak ditemukan, tampilkan pesan kesalahan
                    echo '<p style="color: red;">Username atau password anda salah</p>';
                }
            }
        ?>
        <br />
        <p>Belum punya akun? daftar <a style="color:#00C;" href="registrasi.php">DISINI</a></p>
        <p>atau klik <a style="color:#00C;" href="index.php">Kembali</a></p>
    </div>
</body>
</html>
