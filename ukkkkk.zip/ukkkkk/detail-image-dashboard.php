<?php
    // Mengaktifkan error reporting
    error_reporting(0);

    // Memasukkan file koneksi database
    include 'db.php';

    // Mengambil informasi kontak admin
    $kontak = mysqli_query($conn, "SELECT admin_telp, admin_email, admin_address FROM tb_admin WHERE admin_id = 2");
    $a = mysqli_fetch_object($kontak);

    // Mengambil informasi gambar berdasarkan ID yang diberikan
    $produk = mysqli_query($conn, "SELECT * FROM tb_image WHERE image_id = '".$_GET['id']."' ");
    $p = mysqli_fetch_object($produk);

    // Mengambil jumlah like dari database
    $jumlahLike = mysqli_query($conn, "SELECT COUNT(*) AS total_likes FROM likefoto WHERE image_id = '".$_GET['id']."'");
    $row = mysqli_fetch_assoc($jumlahLike);
    $totalLikes = $row['total_likes'];

    // Pastikan session dimulai
    session_start();

    // Periksa apakah pengguna sudah login
    if (!isset($_SESSION['status_login'])) {
        // Jika tidak, arahkan pengguna kembali ke halaman login
        header("Location: login.php");
        exit();
    }

    // Memproses form jika metode request adalah POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['like'])) {
            $imageId = $_GET['id'];
            $adminId = $_SESSION['id'];
            
            // Ambil informasi like pengguna dari sesi
            $liked = isset($_SESSION['liked_' . $imageId]) ? $_SESSION['liked_' . $imageId] : null;

            // Periksa apakah pengguna sudah memberikan like sebelumnya
            if ($liked) {
                // Jika sudah memberikan like, kurangi like dari sesi
                $_SESSION['liked_' . $imageId] -= 1;
                // Kurangi like dari basis data
                mysqli_query($conn, "DELETE FROM likefoto WHERE image_id = '$imageId' AND admin_id = '$adminId'");
            } else {
                // Jika belum memberikan like, tambahkan like ke sesi
                $_SESSION['liked_' . $imageId] = 1;

                // Tambahkan like ke basis data
                $tanggalLike = date("Y-m-d H:i:s");
                mysqli_query($conn, "INSERT INTO likefoto (image_id, admin_id, tanggallike) VALUES ('$imageId', '$adminId', '$tanggalLike')");
            }

            // Refresh halaman setelah like ditekan
            header("Location: ".$_SERVER['PHP_SELF']."?id=".$_GET['id']);
            exit();
        } elseif (isset($_POST['comment'])) {
            // Handle comment submission
            
            // Ambil admin ID dari session
            $adminId = $_SESSION['id'];

            // Ambil image ID dari $_GET
            $imageId = $_GET['id'];

            // Sanitasi input komentar
            $isiKomentar = mysqli_real_escape_string($conn, $_POST['comment']);

            // Tanggal komentar
            $tanggalKomentar = date("Y-m-d H:i:s");

            // Simpan komentar ke dalam basis data
            mysqli_query($conn, "INSERT INTO komentarfoto (image_id, admin_id, isikomentar, tanggalkomentar) VALUES ('$imageId', '$adminId', '$isiKomentar', '$tanggalKomentar')");

            // Refresh halaman setelah komentar dikirim
            header("Location: ".$_SERVER['PHP_SELF']."?id=".$_GET['id']);
            exit();
        } elseif (isset($_POST['edit_comment'])) {
            // Handle edit comment
            
            // Ambil admin ID dari session
            $adminId = $_SESSION['id'];

            // Ambil image ID dari $_GET
            $imageId = $_GET['id'];

            // Sanitasi input komentar
            $isiKomentar = mysqli_real_escape_string($conn, $_POST['edited_comment']);


        } if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (isset($_POST['delete_comment'])) {
                // Pastikan bahwa pengguna sudah login
                if (!isset($_SESSION['status_login'])) {
                    // Jika tidak, arahkan pengguna kembali ke halaman login
                    header("Location: login.php");
                    exit();
                }
                
                // Hapus komentar dengan ID yang dikirimkan
                $commentId = $_POST['komentarid'];
                
                // Lakukan validasi dan sanitasi jika diperlukan
                
                // Lakukan penghapusan komentar dari basis data menggunakan ID yang diberikan
                mysqli_query($conn, "DELETE FROM komentarfoto WHERE komentarid = '$commentId'");
                
                // Tambahkan pesan sukses atau pengalihan ke halaman tertentu jika diperlukan
            }
        }
        
    }

    // Mengaktifkan error reporting
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Foto</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Tambahkan CSS berikut untuk menyesuaikan layout */
        .like-comment-container {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .like-button {
            padding: 10px 20px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 10px;
        }

        .like-count {
            font-weight: bold;
        }

        .comment-form {
            margin-top: 20px;
        }

        .comment-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            resize: vertical;
        }

        .comment-form button {
            padding: 8px 15px;
            background-color: #C70039;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .comments-container {
            max-height: 300px;
            overflow-y: auto;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
        }

        .comment {
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        .comment p {
            margin-bottom: 5px;
        }

        .comment-info {
            font-size: 12px;
            color: #999;
        }
    </style>
</head>
<body>
   <!-- header.php -->

   <header>
    <div class="container">
    <a href="index.php" style="font-size: 24px; display: block; text-align: center;">WEB GALERI FOTO</a>
        <input type="checkbox" id="toggle-menu" style="display: none;">
        <label for="toggle-menu" class="toggle-menu">&#9776;</label>
        <ul class="menu">
        <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="profil.php">Profil</a></li>
            <li><a href="data-image.php">Data Foto</a></li>
            <li><a href="Keluar.php">Keluar</a></li>
        </ul>
    </div>
</header>


    <!-- Search -->
    <div class="search">
        <div class="container">
            <form action="galeri.php" method="GET">
                <input type="text" name="search" placeholder="Cari Foto" value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>" />
                <input type="hidden" name="kat" value="<?php echo isset($_GET['kat']) ? $_GET['kat'] : ''; ?>" />
                <input type="submit" name="cari" value="Cari Foto" />
            </form>
        </div>
    </div>

    <!-- Product Detail -->
    <div class="section">
        <div class="container">
            <h3>Detail Foto</h3>
            <div class="box">
                <div class="col-2">
                    <img src="foto/<?php echo $p->image ?>" width="100%" /> 
                </div>
                <div class="col-2">
                    <h3><?php echo $p->image_name ?><br />Kategori : <?php echo $p->category_name  ?></h3>
                    <h4>Nama User : <?php echo $p->admin_name ?><br />
                    Upload Pada Tanggal : <?php echo $p->date_created  ?></h4>
                    <p>Deskripsi :<br />
                        <?php echo $p->image_description ?>
                    </p>
                </div>
                <div class="col-2">
                    <!-- Like button form -->
                    <form method="post">
                        <input type="hidden" name="like" value="1">
                        <button type="submit" class="like-button">
                            Like <span class="like-count"><?php echo $totalLikes; ?></span>
                        </button>
                    </form>

                    <!-- Comment form -->
                    <form method="post">
                        <textarea name="comment" placeholder="Add a comment"></textarea>
                        <button type="submit">Post Comment</button>
                    </form>

                    <!-- Menampilkan komentar -->
                    <?php
                        // Mengatur jumlah komentar per halaman
                        $komentarPerHalaman = 10;

                        // Mengambil nomor halaman dari parameter GET, atau gunakan halaman pertama sebagai default
                        $halaman = isset($_GET['halaman']) ? $_GET['halaman'] : 1;

                        // Menghitung offset untuk kueri SQL
                        $offset = ($halaman - 1) * $komentarPerHalaman;

                        // Mengambil jumlah total komentar
                        $queryTotalKomentar = "SELECT COUNT(*) AS total_komentar FROM komentarfoto WHERE image_id = '".$_GET['id']."'";
                        $resultTotalKomentar = mysqli_query($conn, $queryTotalKomentar);
                        $rowTotalKomentar = mysqli_fetch_assoc($resultTotalKomentar);
                        $totalKomentar = $rowTotalKomentar['total_komentar'];

                        // Menghitung total halaman berdasarkan jumlah komentar per halaman
                        $totalHalaman = ceil($totalKomentar / $komentarPerHalaman);

                        // Mengambil komentar untuk halaman saat ini
                        $queryKomentar = "SELECT komentarfoto.*, tb_admin.admin_name 
                                          FROM komentarfoto 
                                          INNER JOIN tb_admin ON komentarfoto.admin_id = tb_admin.admin_id 
                                          WHERE komentarfoto.image_id = '".$_GET['id']."' 
                                          ORDER BY komentarfoto.tanggalkomentar DESC 
                                          LIMIT $offset, $komentarPerHalaman";

                        $resultKomentar = mysqli_query($conn, $queryKomentar);

                        // Menampilkan komentar
                        if(mysqli_num_rows($resultKomentar) > 0) {
                            while($row = mysqli_fetch_assoc($resultKomentar)) {
                                // Tampilkan komentar
                                echo "<div class='comment'>";
                                echo "<p><strong>".$row['admin_name']."</strong> - ".$row['tanggalkomentar']."</p>";
                                echo "<p>".$row['isikomentar']."</p>";
                                
                               // Tampilkan tombol hapus hanya jika pengguna adalah pemilik komentar
    if ($row['admin_id'] == $_SESSION['id']) {
        echo "<form method='post'>";
        echo "<input type='hidden' name='komentarid' value='" . $row['komentarid'] . "'>"; // Menambahkan input tersembunyi untuk menyimpan ID komentar
        echo "<button type='submit' name='delete_comment' style='background-color: #C70039; color: #fff; border: none; border-radius: 3px; cursor: pointer;'>Hapus</button>";
        echo "</form>";
    }
    
    echo "</div>";
}

                                
                              
                        } else {
                            // Jika tidak ada komentar
                            echo "<p>No comments yet.</p>";
                        }

                        // Tampilkan navigasi halaman jika ada lebih dari satu halaman
                        if($totalHalaman > 1) {
                            echo "<div class='pagination'>";
                            if($halaman > 1) {
                                // Tampilkan tautan ke halaman sebelumnya jika tidak ada di halaman pertama
                                echo "<a href='?id=".$_GET['id']."&halaman=".($halaman - 1)."'>Halaman Sebelumnya</a>";
                            }

                            // Tampilkan tautan ke setiap halaman
                            for($i = 1; $i <= $totalHalaman; $i++) {
                                echo "<a href='?id=".$_GET['id']."&halaman=".$i."'".($halaman == $i ? " class='active'" : "").">".$i."</a>";
                            }

                            if($halaman < $totalHalaman) {
                                // Tampilkan tautan ke halaman berikutnya jika tidak ada di halaman terakhir
                                echo "<a href='?id=".$_GET['id']."&halaman=".($halaman + 1)."'>Halaman Berikutnya</a>";
                            }
                            echo "</div>";
                        }
                    ?> 
                </div>
            </div>
        </div>
    </div>
    

    <!-- Footer -->
    <footer>
        <div class="container">
            <small>Copyright &copy; 2024 - Web Galeri
            </div>
    </footer>
</body>
</html>